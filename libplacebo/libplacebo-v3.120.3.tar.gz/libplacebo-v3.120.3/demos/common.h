#pragma once

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// Needed to include the generated in-tree config.h
#include "../src/config.h"

#include <libplacebo/context.h>
#include <libplacebo/renderer.h>

#include "config_demos.h"
