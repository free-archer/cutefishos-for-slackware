#include "config.h"
#include "include/libplacebo/@header@"

int main()
{
    return 0;
}
